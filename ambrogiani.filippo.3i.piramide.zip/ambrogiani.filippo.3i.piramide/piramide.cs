
namespace Piramide{
    public static class Piramide {

        public static int Piani( int mattoni )
        {
            if(mattoni<1){
                return 0;
            }
            double tot = 0;
            int piani = 0;
            double num = 0;
            double eccesso = 0;
            double counter = 1;
            while(mattoni > tot) //maggiore o maggiore uguale
            {
                num = System.Math.Pow(counter, 2);
                counter += 2;
                tot = tot + num;
                if (mattoni<tot)
                {   
                    eccesso = counter-mattoni;
                    break;
                }     
                piani ++;
            }
            return piani;
            /*
                1) 1^2 = 1
                2) 3^2 = 9
                3) 5^2 = 25
                4) 7^2 = 49
            */
        }
        public static int Rimanenti( int mattoni )
        {
            if(mattoni<1){
                return 0;
            }
            double tot = 0;
            int piani = 0;
            double num = 0;
            double eccesso = 0;
            double counter = 1;
            int intEccesso=0;
            while(mattoni > tot) //maggiore o maggiore uguale
            {
                num = System.Math.Pow(counter, 2);
                counter += 2;
                tot = tot + num;
                if (mattoni<tot)
                {   
                    eccesso = mattoni-1;
                    break;
                }     
                piani ++;
            }
            for (int i = 0; i < eccesso; i++)
            {
                intEccesso++;
            }
            return intEccesso;
        }

    }
}